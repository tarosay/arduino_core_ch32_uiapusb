/*
  Arduino.h - Main include file for the Arduino SDK
  Copyright (c) 2005-2013 Arduino Team.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef Arduino_h
#define Arduino_h

#ifndef GCC_VERSION
#define GCC_VERSION (__GNUC__ * 10000 \
                     + __GNUC_MINOR__ * 100 \
                     + __GNUC_PATCHLEVEL__)
#endif
#if GCC_VERSION < 60300
  #error "GCC version 6.3 or higher is required"
#endif

#ifdef __IN_ECLIPSE__
  // #include "SrcWrapper.h"
#endif

#include "wiring.h"

/* sketch */
#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

extern void setup(void) ;
extern void loop(void) ;

void yield(void);

#ifdef __cplusplus
} // extern "C"
#endif // __cplusplus

// Move the following content to the file wiring.h  //by TempersLee
// #ifdef __cplusplus
// #include "WCharacter.h"
// #include "WString.h"
// #include "WMath.h"
// #  include <Tone.h>
// #  include <HardwareSerial.h>
// #endif

// Include pins variant
#include "pins_arduino.h"

#endif // Arduino_h
